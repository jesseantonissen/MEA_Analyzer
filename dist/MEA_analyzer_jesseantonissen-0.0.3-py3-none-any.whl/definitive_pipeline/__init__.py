import MEA_analyzer_jesseantonissen
from MEA_analyzer_jesseantonissen.get_nice_message import get_nice_message

# The init file can be left empty or you could provide a nice message as well as some variables describing your Library
Message = "Have fun with all our functions by analyzing your MEA files!"