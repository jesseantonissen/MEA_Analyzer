# The init file can be left empty or you could provide a nice message as well as some variables describing your Library
Message = "Have fun with all our functions by analyzing your MEA files!"